from setuptools import setup, find_packages

setup(
    name='mlcslr',
    version='0.0.1',
    packages=find_packages(),
    install_requires=['numpy'],
    author='aknckmppjs',
    description='mlcslr package'
)